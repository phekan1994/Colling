
let peer;
let localStream;

async function startCall() {
  const roomID = document.getElementById('room').value;

  localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  document.getElementById('localVideo').srcObject = localStream;

  peer = new SimplePeer({
    initiator: location.hash === '#1',
    trickle: false,
    stream: localStream
  });

  peer.on('signal', data => {
    console.log('SIGNAL', JSON.stringify(data));
  });

  peer.on('stream', stream => {
    document.getElementById('remoteVideo').srcObject = stream;
  });
}
